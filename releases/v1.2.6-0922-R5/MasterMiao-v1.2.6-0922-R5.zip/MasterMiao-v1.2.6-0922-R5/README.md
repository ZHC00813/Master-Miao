# MasterMiao V1.2.6 · 0922-R5

文件版本：1.2.6.5。Windows x64 完整便携包，包含程序、运行依赖、STEP 宏、源代码及构建脚本。

## 开始使用

1. 将整个压缩包解压到可写文件夹，不要直接在压缩包中运行。
2. 本机需安装 .NET Framework 4.8 和可正常使用的 SolidWorks。此次实测环境为 SolidWorks 2024 SP0.1。
3. 运行 MasterMiao.exe。程序与 SolidWorks 使用相同 Windows 权限级别。
4. 读取 SLDPRT，完成命名和分类后导出。

## 从旧版继续工作

先在旧版保存项目，再关闭旧版。在新版中“打开项目”，选择原来的 .swbody.json 文件。项目的 Previews 文件夹应一起保留。

如果在原目录升级，先备份旧目录并关闭程序，再更新运行文件；保留原有 Data、项目和 Previews。本包不包含个人项目、CAD 文件或旧版运行数据。

- 提示源零件未保存：点击“保存源文件并重读”，确认后完成保存和扫描，并恢复可匹配实体的名称、分类、勾选。
- 源零件已另存或移动：选中原源文件记录，点击“重新关联”。无需删除后重新添加。
- 同名文档冲突或文件占用：按提示检查实际路径，保存并关闭冲突文档，或关联到实际使用的零件。
- 几何改变或无法唯一对应的实体需要人工检查；重读前会自动备份命名项目。

## 包内文件

- MasterMiao.exe：主程序。
- MasterMiao.exe.config：.NET 运行配置。
- MasterMiao.StepMacro.dll：STEP 导出宏，需与主程序放在一起。
- SolidWorks.Interop.*.dll：SolidWorks API 互操作组件。
- Source：源代码、测试源码、资源与构建工具。
- R5_FIX_NOTES.md：修复内容与验证范围。
- THIRD_PARTY_NOTICE.md：第三方组件说明。
- SHA256SUMS.txt：包内文件完整性清单。

## 重新构建

在 Source 目录运行 PowerShell：

```powershell
.\build.ps1
# 自定义 SolidWorks API 路径：
.\build.ps1 -SolidWorksApiPath 'D:\SOLIDWORKS\api\redist'
```

默认产物位于 Source\build。构建需要本机 .NET Framework C# 编译器及 SolidWorks API 程序集。
